import React from "react"
const Navbar = () => {
    return (
        <div className="bg-[#50d71e] h-16 flex items-center w-auto min-w-full">
            <p className="text-white px-3 font-semibold">ProductInfo Management</p>
        </div>
    )

}
export default Navbar