package com.Management.ProductListing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductListingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
