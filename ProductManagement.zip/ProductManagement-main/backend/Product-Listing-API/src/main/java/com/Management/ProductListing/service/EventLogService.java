package com.Management.ProductListing.service;

import com.Management.ProductListing.model.EventLog;

public interface EventLogService {
    public EventLog saveEvent(EventLog eventLog);
}
